import { MovementLimiterV13 } from "./movement.js";

Hooks.once("ready", () => {
  game.coc7MovementLimiter = new MovementLimiterV13();
  game.coc7MovementLimiter.activate();
});
