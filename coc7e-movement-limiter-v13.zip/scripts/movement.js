export class MovementLimiterV13 {
  constructor() {
    this.active = false;
  }

  activate() {
    if (this.active) return;
    this.active = true;
    console.log("CoC 7e Movement Limiter | Activated for v13");

    Hooks.on("dragToken", this._onTokenDrag.bind(this));
    Hooks.on("dropToken", this._onTokenDrop.bind(this));
  }

  _getMaxMovement(token) {
    const mov = token.actor?.system?.characteristics?.mov?.value || 8;
    return {
      walk: mov * 5,
      run: mov * 10
    };
  }

  _onTokenDrag(token, dragData) {
    if (!token.actor) return;
    const { walk, run } = this._getMaxMovement(token);

    const ruler = canvas.controls.ruler;
    const distance = ruler._state?.distance || 0;
    let color = "green";
    if (distance > walk) color = "yellow";
    if (distance > run) color = "red";

    ruler.color = color;
  }

  async _onTokenDrop(token, dragData) {
    if (!token.actor) return true;
    const { run } = this._getMaxMovement(token);

    const ruler = canvas.controls.ruler;
    const distance = ruler._state?.distance || 0;

    if (distance > run) {
      ui.notifications.warn(`You cannot move more than ${run} ft (running limit)!`);
      return false;
    }
    return true;
  }
}
